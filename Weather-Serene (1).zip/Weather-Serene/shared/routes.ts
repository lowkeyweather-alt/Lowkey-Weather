import { z } from 'zod';
import { insertSearchSchema, searches } from './schema';

export type InsertSearch = z.infer<typeof insertSearchSchema>;

export const api = {
  searches: {
    list: {
      method: 'GET' as const,
      path: '/api/searches',
      responses: {
        200: z.array(z.custom<typeof searches.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/searches',
      input: insertSearchSchema,
      responses: {
        201: z.custom<typeof searches.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
