import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const searches = pgTable("searches", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  searchedAt: timestamp("searched_at").defaultNow(),
});

export const insertSearchSchema = createInsertSchema(searches).omit({ id: true, searchedAt: true });

export type Search = typeof searches.$inferSelect;
export type InsertSearch = z.infer<typeof insertSearchSchema>;
