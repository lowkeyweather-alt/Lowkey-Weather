import { db } from "./db";
import { searches, type Search, type InsertSearch } from "@shared/schema";

export interface IStorage {
  getSearches(): Promise<Search[]>;
  createSearch(search: InsertSearch): Promise<Search>;
}

export class DatabaseStorage implements IStorage {
  async getSearches(): Promise<Search[]> {
    return await db.select().from(searches);
  }

  async createSearch(insertSearch: InsertSearch): Promise<Search> {
    const [search] = await db.insert(searches).values(insertSearch).returning();
    return search;
  }
}

export const storage = new DatabaseStorage();
