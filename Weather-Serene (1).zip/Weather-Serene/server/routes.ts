import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Searches API
  app.get(api.searches.list.path, async (req, res) => {
    const results = await storage.getSearches();
    res.json(results);
  });

  app.post(api.searches.create.path, async (req, res) => {
    try {
      const input = api.searches.create.input.parse(req.body);
      const search = await storage.createSearch(input);
      res.status(201).json(search);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
