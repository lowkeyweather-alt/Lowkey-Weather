import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertSearch } from "@shared/routes";

// --- Types for Open-Meteo API Response ---
interface GeoLocation {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  admin1?: string;
}

interface WeatherData {
  current: {
    temperature_2m: number;
    relative_humidity_2m: number;
    is_day: number;
    precipitation: number;
    weather_code: number;
    cloud_cover: number;
    wind_speed_10m: number;
  };
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
  };
}

// --- Helper: Get browser location ---
function getPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(resolve, reject);
  });
}

// --- Hooks ---

export function useWeather(lat: number | null, lon: number | null) {
  return useQuery({
    queryKey: ["weather", lat, lon],
    queryFn: async () => {
      if (lat === null || lon === null) return null;
      
      const params = new URLSearchParams({
        latitude: lat.toString(),
        longitude: lon.toString(),
        current: "temperature_2m,relative_humidity_2m,is_day,precipitation,weather_code,cloud_cover,wind_speed_10m",
        daily: "weather_code,temperature_2m_max,temperature_2m_min",
        timezone: "auto",
      });

      const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`);
      if (!res.ok) throw new Error("Failed to fetch weather data");
      return (await res.json()) as WeatherData;
    },
    enabled: lat !== null && lon !== null,
  });
}

export function useGeoSearch(query: string) {
  return useQuery({
    queryKey: ["geo", query],
    queryFn: async () => {
      if (!query || query.length < 2) return [];
      
      const res = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=10&language=en&format=json`
      );
      if (!res.ok) throw new Error("Failed to search location");
      const data = await res.json();
      return (data.results || []) as GeoLocation[];
    },
    enabled: query.length >= 2,
    staleTime: 1000 * 60 * 5, // Cache for 5 mins
  });
}

export function useCurrentLocation() {
  return useQuery({
    queryKey: ["current-location"],
    queryFn: async () => {
      const pos = await getPosition();
      return {
        lat: pos.coords.latitude,
        lon: pos.coords.longitude,
      };
    },
    retry: false,
  });
}

export function useRecordSearch() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertSearch) => {
      // Validate with shared schema (though here we just pass simple JSON)
      const res = await fetch(api.searches.create.path, {
        method: api.searches.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to record search");
      return res.json();
    },
    onSuccess: () => {
      // Optional: invalidate recent searches list if we had one
    }
  });
}
