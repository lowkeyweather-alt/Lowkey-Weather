import { format } from "date-fns";
import { Cloud, Sun, CloudRain, CloudSnow, CloudLightning, CloudFog } from "lucide-react";
import { motion } from "framer-motion";

interface ForecastRowProps {
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
  };
}

function WeatherIcon({ code, className }: { code: number; className?: string }) {
  if (code === 0 || code === 1) return <Sun className={`${className} text-red-500`} />;
  if (code === 2 || code === 3) return <Cloud className={`${className} text-neutral-500`} />;
  if (code >= 45 && code <= 48) return <CloudFog className={`${className} text-slate-400`} />;
  if (code >= 51 && code <= 67) return <CloudRain className={`${className} text-blue-500`} />;
  if (code >= 71 && code <= 77) return <CloudSnow className={`${className} text-sky-200`} />;
  if (code >= 80 && code <= 82) return <CloudRain className={`${className} text-blue-400`} />;
  if (code >= 95) return <CloudLightning className={`${className} text-amber-500`} />;
  return <Cloud className={`${className} text-neutral-400`} />;
}

export function ForecastRow({ daily }: ForecastRowProps) {
  // Take next 5 days (skipping today usually, but OpenMeteo includes today as index 0)
  // Let's show next 4 days starting from tomorrow (index 1)
  const indices = [1, 2, 3, 4];

  return (
    <div className="w-full max-w-4xl mx-auto px-6 pb-12 pt-8">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {indices.map((index, i) => (
          <motion.div
            key={daily.time[index]}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + (i * 0.1), duration: 0.5 }}
            className="flex flex-col items-center justify-center p-4 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-[20px] transition-colors group"
          >
            <span className="text-[11px] uppercase tracking-[0.15em] text-white/70 mb-2 font-bold font-body">
              {format(new Date(daily.time[index]), "EEEE")}
            </span>
            
            <div className="flex items-center gap-3 font-display">
              <span className="text-3xl font-bold text-white tracking-tight">
                {Math.round(daily.temperature_2m_max[index])}
              </span>
              <WeatherIcon 
                code={daily.weather_code[index]} 
                className="w-5 h-5 opacity-100 drop-shadow-sm" 
              />
            </div>

            <div className="w-full h-1.5 bg-white/10 rounded-full mt-4 overflow-hidden relative">
              <div 
                className="absolute inset-y-0 bg-gradient-to-r from-blue-400 to-red-400 rounded-full"
                style={{ 
                  left: '20%', 
                  right: '20%' 
                }}
              />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
