import { motion } from "framer-motion";

interface WeatherBackgroundProps {
  weatherCode: number;
  isDay: number;
}

export function WeatherBackground({ weatherCode, isDay }: WeatherBackgroundProps) {
  // Determine abstract shape color/mood based on weather code
  // Open-Meteo WMO codes: 
  // 0: Clear, 1-3: Partly Cloudy, 45-48: Fog, 51-67: Rain, 71-77: Snow, 80-82: Showers, 95-99: Storm
  
  let accentColor = "bg-amber-400"; // Default yellow sun
  let showSun = true;
  let cloudColor = "bg-white"; // Default white clouds
  let bgColor = "bg-[#e0e0e0]";

  if (!isDay) {
    accentColor = "bg-neutral-300"; // Gray/White moon
    showSun = true; // Moon
    cloudColor = "bg-black";
    bgColor = "bg-[#1a1a2e]";
  } else if (weatherCode >= 71 && weatherCode <= 77) { // Snow
    accentColor = "bg-blue-100";
    showSun = false;
    cloudColor = "bg-neutral-200";
    bgColor = "bg-[#d1d5db]";
  } else if (weatherCode >= 51 && weatherCode <= 82) { // Rain/Showers
    accentColor = "bg-blue-600";
    showSun = false;
    cloudColor = "bg-neutral-700";
    bgColor = "bg-[#9ca3af]";
  } else if (weatherCode >= 3 && weatherCode <= 48) { // Overcast/Fog
    accentColor = "bg-amber-200";
    showSun = false; 
    cloudColor = "bg-neutral-400";
    bgColor = "bg-[#cbd5e1]";
  } else if (weatherCode >= 1 && weatherCode <= 2) { // Partly Cloudy
    accentColor = "bg-amber-400";
    showSun = true;
    cloudColor = "bg-white";
    bgColor = "bg-[#e2e8f0]";
  }

  return (
    <div className={`fixed inset-0 -z-10 overflow-hidden pointer-events-none transition-colors duration-1000 ${bgColor}`}>
      <div className="absolute inset-0 flex items-center justify-center -translate-y-24">
        <div className="relative">
          {/* Large Abstract Sun/Mood circle */}
          {showSun && (
            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                className={`w-[450px] h-[450px] rounded-full ${accentColor} blur-none opacity-100 shadow-[0_0_100px_rgba(0,0,0,0.1)] relative overflow-hidden`}
              >
                {!isDay && (
                  <>
                    <div className="absolute top-10 left-20 w-16 h-16 bg-black/10 rounded-full blur-sm" />
                    <div className="absolute top-40 left-60 w-24 h-24 bg-black/10 rounded-full blur-md" />
                    <div className="absolute bottom-20 left-32 w-20 h-20 bg-black/10 rounded-full blur-sm" />
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[450px] h-[450px] bg-gradient-to-tr from-transparent via-white/5 to-white/20 pointer-events-none" />
                  </>
                )}
              </motion.div>
            </div>
          )}
          
          {/* Overlapping Cloud-like spheres (matte 3d style) - Now rounder and more organic */}
          <motion.div 
            animate={{ x: [0, 15, 0], y: [0, -10, 0], scale: [1, 1.05, 1] }}
            transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute top-24 -left-16 w-[280px] h-[280px] ${cloudColor} rounded-full shadow-2xl z-10`}
          />
          <motion.div 
            animate={{ x: [0, -20, 0], y: [0, 12, 0], scale: [1.05, 1, 1.05] }}
            transition={{ duration: 14, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            className={`absolute top-10 left-24 w-[320px] h-[320px] ${cloudColor} opacity-90 rounded-full shadow-2xl z-10`}
          />
          <motion.div 
            animate={{ x: [0, 10, 0], y: [0, 15, 0], scale: [1, 1.1, 1] }}
            transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            className={`absolute top-40 left-48 w-[240px] h-[240px] ${cloudColor} opacity-95 rounded-full shadow-2xl z-10`}
          />
        </div>
      </div>
      
      {/* Grain overlay for "matte" texture */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-multiply" 
           style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }} 
      />
    </div>
  );
}
