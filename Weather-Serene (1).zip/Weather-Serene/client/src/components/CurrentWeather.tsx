import { motion } from "framer-motion";
import { format } from "date-fns";

interface CurrentWeatherProps {
  temperature: number;
  weatherCode: number;
  humidity: number;
  windSpeed: number;
  cityName: string;
}

// Map WMO Weather Codes to descriptive strings
const getWeatherDescription = (code: number): string => {
  const map: Record<number, string> = {
    0: "Clear sky.",
    1: "Mainly clear.",
    2: "Partly cloudy.",
    3: "Overcast.",
    45: "Foggy.",
    48: "Depositing rime fog.",
    51: "Light drizzle.",
    53: "Moderate drizzle.",
    55: "Dense drizzle.",
    61: "Slight rain.",
    63: "Moderate rain.",
    65: "Heavy rain.",
    71: "Slight snow.",
    73: "Moderate snow.",
    75: "Heavy snow.",
    80: "Slight rain showers.",
    81: "Moderate rain showers.",
    82: "Violent rain showers.",
    95: "Thunderstorm.",
    96: "Thunderstorm with hail.",
    99: "Thunderstorm with heavy hail."
  };
  return map[code] || "Unknown weather.";
};

const getWeatherTone = (code: number): string => {
  if (code === 0) return "Beautifully clear.";
  if (code <= 2) return "Kinda nice out.";
  if (code === 3) return "Grey skies today.";
  if (code >= 45 && code <= 48) return "Can't see much.";
  if (code >= 51 && code <= 67) return "Bring an umbrella.";
  if (code >= 71) return "Stay warm.";
  if (code >= 95) return "Stay inside.";
  return "Just regular weather.";
};

export function CurrentWeather({ temperature, weatherCode, humidity, windSpeed, cityName }: CurrentWeatherProps) {
  const description = getWeatherDescription(weatherCode);
  const tone = getWeatherTone(weatherCode);

  // Dynamic text color based on weather code (darkness of graphics)
  // Rainy/Stormy/Night/Snowy typically have darker backgrounds/shapes
  const isDarkGraphics = weatherCode >= 51 || weatherCode >= 95 || (weatherCode >= 3 && weatherCode <= 48);
  const textColor = isDarkGraphics ? "text-white" : "text-neutral-900";
  const subTextColor = isDarkGraphics ? "text-white/80" : "text-neutral-500";
  const tertiaryColor = isDarkGraphics ? "text-white/50" : "text-neutral-400";
  const shadowClass = isDarkGraphics ? "drop-shadow-[0_20px_30px_rgba(0,0,0,0.4)]" : "drop-shadow-[0_4px_6px_rgba(0,0,0,0.1)]";

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center px-6 relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <h1 className={`text-[12rem] md:text-[18rem] lg:text-[24rem] leading-[0.85] font-display font-medium ${textColor} tracking-[-0.05em] uppercase ${shadowClass} relative z-30 transition-colors duration-500`}>
          {Math.round(temperature)}
        </h1>
        
        <div className="mt-4 space-y-1 relative z-30">
          <p className={`text-xl md:text-2xl font-display ${textColor} uppercase tracking-widest drop-shadow-md transition-colors duration-500`}>
            {description}
          </p>
          <div className="flex items-center justify-center gap-4 mt-2">
            <span className={`text-sm font-medium ${subTextColor} drop-shadow-sm transition-colors duration-500`}>H: {Math.round(temperature + 4)}°</span>
            <span className={`text-sm font-medium ${subTextColor} drop-shadow-sm transition-colors duration-500`}>L: {Math.round(temperature - 3)}°</span>
          </div>
          <p className={`text-xs ${tertiaryColor} font-body mt-4 italic transition-colors duration-500`}>
            {tone}
          </p>
        </div>

        <div className={`mt-12 flex items-center justify-center gap-8 md:gap-16 ${tertiaryColor} text-sm font-medium uppercase tracking-wider transition-colors duration-500`}>
          <div className="flex flex-col items-center gap-1">
            <span>Humidity</span>
            <span className={subTextColor}>{humidity}%</span>
          </div>
          <div className={`w-px h-8 ${isDarkGraphics ? 'bg-white/20' : 'bg-neutral-200'} transition-colors duration-500`} />
          <div className="flex flex-col items-center gap-1">
            <span>Wind</span>
            <span className={subTextColor}>{Math.round(windSpeed)} km/h</span>
          </div>
          <div className={`w-px h-8 ${isDarkGraphics ? 'bg-white/20' : 'bg-neutral-200'} transition-colors duration-500`} />
          <div className="flex flex-col items-center gap-1">
            <span>Today</span>
            <span className={subTextColor}>{format(new Date(), "EEE, MMM d")}</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
