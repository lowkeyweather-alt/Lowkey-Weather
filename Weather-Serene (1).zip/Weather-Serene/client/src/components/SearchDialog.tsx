import { useState, useEffect } from "react";
import { Search, MapPin, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useGeoSearch } from "@/hooks/use-weather";

// Simple debounce hook implementation
function useDebounceValue<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

interface SearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLocation: (lat: number, lon: number, name: string) => void;
}

export function SearchDialog({ isOpen, onClose, onSelectLocation }: SearchDialogProps) {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounceValue(query, 500);
  const { data: results, isLoading } = useGeoSearch(debouncedQuery);

  // Lock body scroll when open
  useEffect(() => {
    if (isOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "unset";
    return () => { document.body.style.overflow = "unset"; };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-white/80 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 10, opacity: 0 }}
          className="w-full max-w-lg bg-white rounded-3xl shadow-xl border border-black/5 overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="relative p-6 border-b border-black/5">
            <Search className="absolute left-8 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input
              autoFocus
              className="w-full pl-10 pr-10 py-4 text-2xl font-medium placeholder:text-neutral-300 outline-none text-neutral-800 bg-transparent font-display uppercase tracking-widest"
              placeholder="Type a city..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button 
              onClick={onClose}
              className="absolute right-6 top-1/2 -translate-y-1/2 p-2 hover:bg-neutral-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-neutral-400" />
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto">
            {isLoading && (
              <div className="p-8 text-center text-neutral-400">Searching...</div>
            )}
            
            {!isLoading && results && results.length === 0 && query.length >= 2 && (
              <div className="p-8 text-center text-neutral-400 font-body">No locations found.</div>
            )}

            {!isLoading && results && results.length > 0 && (
              <div className="divide-y divide-black/5">
                {results.map((place) => (
                  <button
                    key={place.id}
                    onClick={() => onSelectLocation(place.latitude, place.longitude, place.name)}
                    className="w-full flex items-center gap-4 p-6 hover:bg-neutral-50 transition-colors text-left group"
                  >
                    <div className="w-10 h-10 rounded-full bg-neutral-100 flex items-center justify-center text-neutral-400 group-hover:bg-white group-hover:shadow-sm transition-all">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-medium text-lg text-neutral-800 font-display">
                        {place.name}
                      </div>
                      <div className="text-sm text-neutral-400">
                        {[place.admin1, place.country].filter(Boolean).join(", ")}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
