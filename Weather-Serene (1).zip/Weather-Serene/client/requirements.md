## Packages
framer-motion | Essential for the soft, atmospheric animations of weather shapes and transitions
date-fns | For friendly date and time formatting (e.g., "Monday, 12:30 PM")

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Playfair Display'", "serif"],
  body: ["'DM Sans'", "sans-serif"],
}
